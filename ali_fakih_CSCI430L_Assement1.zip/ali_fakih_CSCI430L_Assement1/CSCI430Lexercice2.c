#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int arr[10];
    int pipe_fd[2];
    pipe(pipe_fd); 

     
    printf("Generated array: ");
    for (int i = 0; i < 10; i++) {
        arr[i] = rand() % 10 + 1;
        printf("%d ", arr[i]);
    }
    printf("\n");

    pid_t pid1 = fork(); 

    if (pid1 == 0) { 
        int min1 = arr[0];
        for (int i = 1; i < 5; i++) {
            if (arr[i] < min1) {
                min1 = arr[i];
            }
        }
        write(pipe_fd[1], &min1, sizeof(min1)); 
        exit(0);
    } else {
        pid_t pid2 = fork(); 

        if (pid2 == 0) { 
            int min2 = arr[5];
            for (int i = 6; i < 10; i++) {
                if (arr[i] < min2) {
                    min2 = arr[i];
                }
            }
            write(pipe_fd[1], &min2, sizeof(min2)); 
            exit(0);
        } else { 
            wait(NULL); 
            wait(NULL); 

            int min1, min2;
            read(pipe_fd[0], &min1, sizeof(min1)); 
            read(pipe_fd[0], &min2, sizeof(min2)); 

            printf("Smallest in first half: %d\n", min1);
            printf("Smallest in second half: %d\n", min2);

            if (min1 == min2) {
                printf("Both are the same: %d\n", min1);
            } else if (min1 < min2) {
                printf("Smallest value: %d\n", min1);
            } else {
                printf("Smallest value: %d\n", min2);
            }
        }
    }

    return 0;
}