#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main() {
    int n;
    printf("Enter an integer n: ");
    scanf("%d", &n);

    int pipe_fd[2];
 

    pid_t pid = fork();

 
    if (pid == 0) { 
        double sum = 0.0;
        for (int i = 1; i <= n; i++) {
            sum += 1.0 / i;
        }
        write(pipe_fd[1], &sum, sizeof(sum)); 
        exit(0); 
    } else { 
        wait(NULL); 

        double sum;
        read(pipe_fd[0], &sum, sizeof(sum));

        printf("Sum of the series: %.2f\n", sum);
        if ((int)sum % 2 == 0) {
            printf("The sum is even.\n");
        } else {
            printf("The sum is odd.\n");
        }
    }

    return 0;
}